Author : M USMAN
This project provides statistical information about a given array and print´s it. Please note that
this source code is developed as a part of course Introduction To Embedded Systems offered by
UC Boulder At Coursera. This source code is available for free distribution under GNU Public License.
The repository contains stats.c and stats.h and executble file stats.
